Entrega do Trabalho Complementar 3 de CGR
Equipe: André L. F. Junior, Miguel. A. Nunes

Arquivos:
	neve.c: Código fonte da simulação de partículas de neve
	
Como Compilar:
	Executar make neve; make run
	
Executando:
	ESC fecha a simulação
	Barra de Espaço Reinicia a simulação
