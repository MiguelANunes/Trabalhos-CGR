Entrega do Trabalho Complementar 2 de CGR
Equipe: André L. F. Junior, Miguel. A. Nunes

Arquivos:
	boneco_neve.c: Parte 1 do trabalho, modelo de um boneco de neve
	castelo.c:  Parte 2 do trabalho, modelo do castelo como detalhado no slide
	castelo2.c: Versão mais elaborada do castelo da Parte 2.
	robo.c: Parte 3 do trabalho, robo com braços e pernas articulados
	
Como Compilar:
	boneco_neve.c : Executar make boneco; make run_boneco
	{castelo, castelo2, robo}.c :  Executar make run_{nome_do_arquivo}
	
Executando:
	Para todos os arquivos, as setas direcionais giram o modelo, setas Esquerda/Direita giram no eixo X, Cima/Baixo giram no eixo Y

	Em particular para o modelo do robo: 
		- As teclas Home/End giram no eixo Z
		- 'Esc', 'q' e 'Q' fecham a janela
		- 'w', 'W', 's', 'S' movem todo o braço do robo para cima/baixo
		- 'e', 'E', 'd', 'D' movem o braço do cotovelo abaixo do robo para cima/baixo
		- 'r', 'R', 'f', 'F' movem toda a perna do robo para cima/baixo
		- 't', 'T', 'g', 'G' movem a perna do joelho abaixo do robo para cima/baixo
	
